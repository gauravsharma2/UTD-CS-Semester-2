# bigdata1
Steps required for the part2:
1.Open the Notebook link provided and allocate the cluster.
2.The input dataset can be changed in the filepath variable mentioned.
2.Run each command one by one and the output to the queries can be seen in the notebook and also in the output path mentioned.
